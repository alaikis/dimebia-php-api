<?php
/**
 * @author Alex Lai
 * @email alex@laialex.com
 * @website https://laialex.com
 * @Date 2025/4/15 15:50
 */

require_once __DIR__ . "../../vendor/autoload.php";

$cl = new \Alaikis\Dimebia\Dimebia("","");
