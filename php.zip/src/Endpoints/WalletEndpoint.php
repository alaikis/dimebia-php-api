<?php
/**
 * @author Alex Lai
 * @email alex@laialex.com
 * @website https://laialex.com
 * @Date 2025/4/14 11:44
 */

namespace Alaikis\Dimebia\Endpoints;


class WalletEndpoint  extends EndpointCollection
{
}