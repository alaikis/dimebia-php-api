<?php
/**
 * @author Alex Lai
 * @email alex@laialex.com
 * @website https://laialex.com
 * @Date 2025/4/14 11:46
 */

namespace Alaikis\Dimebia\Endpoints;


class InvoiceEndpoint  extends EndpointCollection
{

}