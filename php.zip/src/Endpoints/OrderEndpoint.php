<?php
/**
 * @author Alex Lai
 * @email alex@laialex.com
 * @website https://laialex.com
 * @Date 2025/4/14 11:45
 */

namespace Alaikis\Dimebia\Endpoints;


class OrderEndpoint  extends EndpointCollection
{
}