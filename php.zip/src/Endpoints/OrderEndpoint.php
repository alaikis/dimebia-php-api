<?php
/**
 * @author Alex Lai
 * @email alex@laialex.com
 * @website https://laialex.com
 * @Date 2025/4/14 11:45
 */

namespace Alaikis\Dimebia\Endpoints;

use Alaikis\Dimebia\Traits\HttpTrait;

class OrderEndpoint  extends HttpTrait
{
}